public class Grunt extends Employee {

	public Grunt(String lastName, String firstName, String jobTitle) {
		super(lastName, firstName, jobTitle);
		// TODO Auto-generated constructor stub
	}

	public void doWork() {
		throw new UnsupportedOperationException();
	}
}