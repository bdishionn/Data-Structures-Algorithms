public class Manager extends Employee {

	public Manager(String lastName, String firstName, String jobTitle) {
		super(lastName, firstName, jobTitle);
		// TODO Auto-generated constructor stub
	}

	public void takeVaction() {
		throw new UnsupportedOperationException();
	}
}